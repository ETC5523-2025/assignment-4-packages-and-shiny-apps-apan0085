
# SurNamExp

<!-- badges: start -->
<!-- badges: end -->

The goal of SurNamExp is to ...

## Installation

You can install the development version of SurNamExp from [GitHub](https://github.com/) with:

``` r
# install.packages("pak")
pak::pak("ETC5523-2025/assignment-4-packages-and-shiny-apps-apan0085")
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(SurNamExp)
## basic example code
```

